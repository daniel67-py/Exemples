#!/usr/bin/python3
#-*- coding: Utf-8 -*-
import os
import csv
import sqlite3
from datetime import *

###############################################################################
### Classe de création d'une nouvelle base de données
###############################################################################
class Db_analyser_nouveau():
    ###########################################################################
    ### fonction initiale 
    ###########################################################################
    def __init__(self, database):
        ### récupération de l'heure et de la date ###
        instant_t = date.today()
        moment_m = datetime.now()
        ### petite présentation ###
        print("### Framework d'analyse de base de données SQLite3       ###")
        print("### dev. par Meyer Daniel, Janvier 2020 - ver.0.1        ###")
        print(instant_t.strftime("%A %d. %m %Y"), " - ",
              moment_m.strftime("%H:%M:%S"))
        ### fichier à créer ###
        self.database = database
        ### test d'accès ###
        if os.path.exists(self.database) == False and os.path.isfile(self.database) == False:
            ### création de la nouvelle base de données ###
            connexion = sqlite3.connect(self.database)
            connexion.close()
            print("...vérification chemin d'acces fichier...",
                  os.path.exists(self.database))
            print("...vérification si fichier...",
                  os.path.isfile(self.database))
            print("...ACCES DATAS OK...NOUVELLE BASE PRETE...")
        else:
            print("!!! ERREUR - La base de données spécifiée semble déjà présente !!!")


###############################################################################
### Classe principale
###############################################################################
class Db_analyser():
    ###########################################################################
    ### fonction initiale 
    ###########################################################################
    def __init__(self, database):
        ### récupération de l'heure et de la date ###
        instant_t = date.today()
        moment_m = datetime.now()
        ### petite présentation ###
        print("### Framework d'analyse de base de données SQLite3       ###")
        print("### dev. par Meyer Daniel, Janvier 2020 - ver.0.1        ###")
        print(instant_t.strftime("%A %d. %m %Y"), " - ",
              moment_m.strftime("%H:%M:%S"))
        ### fichier à analyser ###
        self.database = database
        ### vérification de l'existence du fichier et de son chemin d'acces ###
        if os.path.exists(self.database) == True and os.path.isfile(self.database) == True:
            print("...vérification chemin d'acces fichier...",
                  os.path.exists(self.database))
            print("...vérification si fichier...",
                  os.path.isfile(self.database))
            print("...ACCES DATAS OK...")
        else: 
            print("Fichier de base de données inexistant...")
            self.database = None

    ###########################################################################
    ### modification d'une entrée dans une table 
    ###########################################################################
    def dba_modif_valeurs(self, table, colonne, ancienne_valeur, nouvelle_valeur):
        """permet de changer une valeur par une nouvelle"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### concaténation de l'instruction à exécuter ###
            instruction = (f"UPDATE {table} SET {colonne} = '{nouvelle_valeur}' WHERE {colonne} = '{ancienne_valeur}'")
            ### affichage de l'instruction pour + de transparence ###
            print(instruction)
            ### essai d'execution des instructions ###
            try:
                c.execute(instruction)
            except:
                print("Impossible de modifier les valeurs, un élément ne correspond pas")
            ### fermeture ###
            connexion.commit()
            connexion.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### ajout d'une entrée dans une table 
    ###########################################################################
    def dba_ajout_valeurs(self, table, *elements):
        """permet de rajouter une entrée dans une table existante"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### concaténation de l'instruction à exécuter ###
            instruction = (f"INSERT INTO {table} VALUES {str(elements)}")
            ### affichage de l'instruction pour + de transparence ###
            print(instruction)
            ### essai d'ajout ###
            try:
                c.execute(instruction)
            ### si impossible renvoi un message d'erreur ###
            except:
                print("Impossible de modifier les valeurs, un élement ne correspond pas")
            ### fermeture ###
            connexion.commit()
            connexion.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### création d'une nouvelle table avec colonnes 
    ###########################################################################
    def dba_nouvelle_table(self, table, *colonnes):
        """permet de créer une nouvelle table avec colonnes"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### concaténation des instructions, 1 pour créer ###
            instruction = (f"CREATE TABLE {table} {str(colonnes)}")
            ### affichage des instructions pour + de transparence ###
            print(instruction)
            ### exécution de l’instruction ###
            c.execute(instruction)
            ### fermeture ###
            connexion.commit()
            connexion.close()
            print("Nouvelle table crée !")
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### suppression d'une table et de son contenu 
    ###########################################################################
    def dba_supprime_table(self, table):
        """permet de supprimer une table de la base de données"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### instruction et exécution de la suppression de la table ###
            instruction = (f"DROP TABLE {table}")
            ### affichage de l'instruction pour + de transparence ###
            print(instruction)
            ### exécution de l'instruction ###
            try:
                c.execute(instruction)
                print(f"La table {table} a été supprimée !")
            except:
                print("Impossible de supprimer la table, elle n'existe pas")
            ### fermeture ###
            connexion.commit()
            connexion.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### suppression d'une entrée 
    ###########################################################################
    def dba_supprime_entree(self, table, colonne, valeur):
        """permet de supprimer une entrée dans une table"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### instruction et exécution de la suppression de la table ###
            instruction = (f"DELETE FROM {table} WHERE {colonne} = '{valeur}'")
            ### affichage de l'instruction pour + de transparence ###
            print(instruction)
            ### exécution de l'instruction ###
            try:
                c.execute(instruction)
                print(f"La valeur {valeur} de la colonne {colonne} a été supprimée !")
            except:
                print("Impossible de supprimer l'entrée, elle n'existe pas")
            ### fermeture ###
            connexion.commit()
            connexion.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### recherche d'une valeur dans une table
    ###########################################################################
    def dba_recherche_valeur(self, table, colonne, valeur):
        """permet de rechercher une valeur dans une table"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### instruction et exécution de la recherche dans la table ###
            if type(valeur) == str:
                instruction = (f"SELECT * FROM {table} WHERE {colonne} = '{valeur}'")
            elif type(valeur) == int or type(valeur) == float:
                instruction = (f"SELECT * FROM {table} WHERE {colonne} = {valeur}")
            ### affichage de l'instruction pour + de transparence ###
            print(instruction)
            ### exécution de l'instruction ###
            try:
                for x in c.execute(instruction):
                    print(x)
            except:
                print("Une ou plusieurs valeurs de recherches ne sont pas bon")
            ### fermeture ###
            connexion.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")

    ###########################################################################
    ### fonction d'affichage de tout le contenu de la base 
    ###########################################################################
    def dba_montre_tout(self):
        """montre l'intégralité du contenu de la base de données"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            ### c analyse les tables, d analyse les colonnes ###
            connexion = sqlite3.connect(self.database)
            connexion.row_factory = sqlite3.Row
            c = connexion.cursor()
            d = connexion.cursor()
            ### autre curseur pour analyser le contenu des tables ###
            connexion2 = sqlite3.connect(self.database)
            e = connexion2.cursor()
            ### affichage du contenu ###
            print("\n...OK... Voilà le contenu :")
            print(self.database)
            print("  |")
            ### analyse par requête du nom des tables présentes avec c ###
            c.execute("""SELECT name FROM sqlite_master WHERE type = 'table' """)
            for x in iter(c.fetchall()):
                ### analyse du nom des colonnes dans la table avec d ###
                d.execute(f"SELECT * FROM {x[0]}")
                ### affichage de l'arborescence ###
                print("  + -",x[0])
                try:
                    print("  |       \ _ _ _ _ _", d.fetchone().keys())
                except:
                    print("  | ")
                ### analyse du contenu des colonnes avec e ###
                for y in e.execute(f"SELECT * FROM {x[0]}"):
                    ligne = ""
                    ### concaténation des données dans une ligne ###
                    for z in range(0, len(y)):
                        ligne = ligne + str(y[z]) + " - "
                    ### affichage des données ###
                    print("  |\t\t\t", ligne)
            ### fermeture de la base de données ###
            connexion.close()
            ### et affichage de fin d'analyse ###
            print("  | \n  |_ FIN DES DATAS !\n")
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")
            
    ###########################################################################
    ### fonction d'affichage de toute la structure de la base 
    ###########################################################################
    def dba_montre_structure(self):
        """montre uniquement la structure de la base de données"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            connexion.row_factory = sqlite3.Row
            c = connexion.cursor()
            d = connexion.cursor()
            ### affichage du contenu ###
            print("\n...OK... Voilà la structure :")
            print(self.database)
            print("  |")
            ### analyse par requête du nom des tables présentes ###
            c.execute("""SELECT name FROM sqlite_master WHERE type = 'table' """)
            for x in iter(c.fetchall()):
                ### analyse du nom des colonnes dans les tables ###
                d.execute(f"SELECT * FROM {x[0]}")
                ### affichage de l'arborescence ###
                print("  + -",x[0])
                try:
                    print("  |       \ _ _ _ _ _", d.fetchone().keys())
                except:
                    print("  | ")
            ### fermeture de la base de données ###                 
            connexion.close()
            ### et affichage de fin d'analyse ###
            print("  | \n  |_ FIN DES DATAS !\n")
        ### si database n'est pas valide ###
        else:
            print("Action impossible car aucune base de données ouverte")
            
    ###########################################################################        
    ### fonction d'impression de la structure de la base dans un txt 
    ###########################################################################
    def dba_edition_structure(self, nom_fichier_sortie = "analyse_dba.txt"):
        """imprimer la structure dans un fichier txt"""
        ### si database est un fichier valide ###
        if self.database != None:
            ### crée et ouvre nom_fichier_sortie pour écriture ###
            fichier_texte = open(nom_fichier_sortie, "w")
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            connexion.row_factory = sqlite3.Row
            c = connexion.cursor()
            d = connexion.cursor()
            ### concaténation des lignes pour affichage et écriture ###
            ligne_entete_01 = "\n...OK...Voilà la structure :"
            ligne_entete_02 = self.database
            ligne_entete_03 = "  |"
            ### affichage des lignes ###
            print(ligne_entete_01)
            print(ligne_entete_02)
            print(ligne_entete_03)
            ### écriture des lignes dans le fichier texte ###
            fichier_texte.write(ligne_entete_01 + "\n")
            fichier_texte.write(ligne_entete_02 + "\n")
            fichier_texte.write(ligne_entete_03 + "\n")
            ### analyse par requête du nom de tables présentes ###
            c.execute("""SELECT name FROM sqlite_master WHERE type = 'table' """)
            for x in iter(c.fetchall()):
                ### analyse du nom des colonnes dans la table ###
                d.execute(f"SELECT * FROM {x[0]}")
                ### concaténation des lignes pour affichage et écriture ###
                ligne_A = "  + -" + str(x[0])
                try:
                    ligne_B = "  |       \ _ _ _ _ _" + str(d.fetchone().keys())
                except:
                    ligne_B = "  | "
                ### affichage des lignes ###
                print(ligne_A)
                print(ligne_B)
                ### écriture des lignes dans le fichier texte ###
                fichier_texte.write(ligne_A + "\n")
                fichier_texte.write(ligne_B + "\n")
            ### définition de la ligne finale pour affichage et écriture ###
            ligne_fin = "  | \n  |_ FIN DES DATAS !\n"
            print(ligne_fin)
            fichier_texte.write(ligne_fin + "\n")
            ### fermeture de la base de données et du fichier texte ###
            connexion.close()
            fichier_texte.close()
        ### si database n'est pas valide ###
        else:
            print("Action impossible, aucune base de données ouverte")

    ###########################################################################
    ### fonction d'impression des valeurs d'une table dans un fichier CSV
    ###########################################################################
    def dba_edition_contenu(self, table, nom_fichier_sortie = "analyse_dba.csv"):
        """imprime le contenu d'une table dans un tableau csv"""
        if self.database != None:
            ### créer et ouvre nom_fichier_sortie pour écriture ###
            fichier_csv = open(nom_fichier_sortie, "w", newline = "")
            ecriture = csv.writer(fichier_csv)
            ### connexion à la base de données ###
            connexion = sqlite3.connect(self.database)
            c = connexion.cursor()
            ### seconde connexion pour récuperer le nom des colonnes ###
            connexion2 = sqlite3.connect(self.database)
            connexion2.row_factory = sqlite3.Row
            d = connexion2.cursor()
            try:
                ### analyse du nom des colonnes et écriture dans le fichier ###
                instruction2 = (f"SELECT * FROM {table}")
                d.execute(instruction2)
                colonnes = d.fetchone()
                ### affichage du nom des colonnes ###
                print(colonnes.keys())
                ### écriture du nom des colonnes dans le fichier ###
                ecriture.writerow(colonnes.keys())
                ### analyse du contenu des colonnes et écriture dans le fichier ###
                instruction = (f"SELECT * FROM {table}")
                for x in c.execute(instruction):
                    print(x)
                    ecriture.writerow(x)
                ### fermeture du fichier csv et de la base de données ###
                fichier_csv.close()
                connexion.close()
            except:
                ### en cas d'impossibilité de lecture de la table ###
                print("La table à analyser n'existe pas")
        ### si database n'est pas valide ###
        else:
            print("Action impossible, aucune base de données ouverte")
