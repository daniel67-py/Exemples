#!/usr/bin/python3
#-*- coding: utf-8 -*-
from tkinter import *

fenetre = Tk()
fenetre.minsize(width = 300, height = 300)
fenetre.resizable(width = False, height = False)
fenetre.title('titre')

fenetre.mainloop()
fenetre.destroy()
