#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

fenetre = Tk()
fenetre.minsize(width = 300, height = 300)
fenetre.resizable(width = False, height = False)
fenetre.title("Bouton")

bouton = Button(fenetre, text = "Quitter", command = fenetre.quit)
bouton.pack()

fenetre.mainloop()
fenetre.destroy()
