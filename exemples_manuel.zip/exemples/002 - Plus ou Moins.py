#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from random import *

###############################################################################
# variables du programme
###############################################################################
selection = randint(0, 10)
nb_tours = 4
###############################################################################
# parties de jeu
###############################################################################
print(f"J'ai choisi un nombre entre 0 et 10, essai de le trouver en {nb_tours} coups.")
for x in range(nb_tours):
    choix = input(" : ")
    try:
        choix = int(choix)
        if choix == selection:
            print("Bravo tu as trouvé !")
            break
        elif choix < selection:
            print("Trop faible, réessaye...")
        elif choix > selection:
            print("Trop fort, réessaye...")
        else:
            print("ce n'est pas une réponse valable !")
    except ValueError or TypeError:
        print("Donne un nombre entier et rien d'autres !")
