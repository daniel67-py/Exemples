#!/usr/bin/python3
#-*- coding : Utf-8 -*-
from random import *

###############################################################################
# variables du programme
###############################################################################
liste = ["pierre", "papier", "ciseaux"] # choix possible
nb_victoire_joueur = 0                  # compteur de victoire joueur
nb_victoire_python = 0                  # compteur de victoire Python
nb_tours = 4                            # nombre de tour(s)

###############################################################################
# parties de jeu
###############################################################################
for x in range(nb_tours):  # une boucle qui va itérer entre 0 et nb_tours
                   
    # choix d'un item avec choice et prise en compte du choix du joueur
    selection = choice(liste)
    print("choisi entre pierre, papier et ciseaux")
    choix = input("que prends tu ?")

    # les conditions sont mises en listes, si l'un d'eux est valable, any()
    # retournera True plus loin dans les conditions if...
    match_nul = [
        choix == "papier" and selection == "papier",
        choix == "pierre" and selection == "pierre",
        choix == "ciseaux" and selection == "ciseaux"
        ]
    gagne = [
        choix == "papier" and selection == "pierre",
        choix == "pierre" and selection == "ciseaux",
        choix == "ciseaux" and selection == "papier"
        ]
    perds = [
        choix == "papier" and selection == "ciseaux",
        choix == "ciseaux" and selection == "pierre",
        choix == "pierre" and selection == "papier"
        ]

    # interrogation des conditions avec any()
    if any(match_nul):
        print("Match nul !")
    elif any(gagne):
        print("Tu gagnes !")
        nb_victoire_joueur = nb_victoire_joueur + 1
    elif any(perds):
        print("Tu perds !")
        nb_victoire_python = nb_victoire_python + 1
    else:
        print("Ce n'est pas un choix valable ! Tu perds !")
        
# au final, une fois la partie finie, on fait le compte des points marqués.
if nb_victoire_joueur > nb_victoire_python:
    print(f"Tu gagnes le match en {nb_tours} rounds avec {nb_victoire_joueur} victoires !")
elif nb_victoire_joueur == nb_victoire_python:
    print("Match nul avec Python...")
elif nb_victoire_joueur < nb_victoire_python:
    print("Python gagne le match !")
