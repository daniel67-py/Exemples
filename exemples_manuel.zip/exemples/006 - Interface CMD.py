#!/usr/bin/python3
# -*- coding: Utf-8 -*-
import cmd

# une petite classe que j'appelle Commando, qui hérite des fonctionnalités du module CMD:
class Commando(cmd.Cmd):
    # donnons lui un message d'accueil.
    intro = "BIENVENUE DANS COMMANDO. \nTapez ? pour lister les commandes."
    # et une invite de commandes.
    prompt = "_commando_$ "
    file = None

    # et voilà quelques fonctions, elles doivent toujours commencer avec do_ 
    def do_bonjour(self, arg):
        print("Bonjour utilisateur ! J'espère que vous allez bien")
        
    def do_gauche(self, arg):
        print("Vous avez dit Gauche ?")
        
    def do_droite(self, arg):
        print("Vous avez dit Droite ?")
        
    def do_fin(self, arg):
        print("Au revoir")
        quit()

   # et les fonctions qui permettent d'enregistrer et de restituer une suite de commandes
   # la fonction record qui permet de commencer un enregistrement dans un fichier de type .cmd passé en argument
    def do_record(self, arg):
        self.file = open(arg, "w")
   # la fonction playback qui permet de restituer une suite de commandes enregistrées dans un fichier .cmd
    def do_playback(self, arg):
        self.close()
        with open(arg, "r") as fichier:
            self.cmdqueue.extend(fichier.read().splitlines())
    # la fonction precmd permet de vérifier que le fichier est ouvert et que la commande précédente ne soit pas playback
    def precmd(self, line):
        line = line.lower()
        if self.file and "playback" not in line:
            print(line, file = self.file)
        return line
    # la fonction close qui permet de refermer le fichier
    def close(self):
        if self.file:
            self.file.close()
            self.file = None

# et hop je boucle le tout pour qu'il puisse tourner:
Commando().cmdloop()
