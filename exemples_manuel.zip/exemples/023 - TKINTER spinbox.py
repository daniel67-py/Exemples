#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# fonction qui retourne les valeurs des étiquettes
def retourne():
    etiquette.configure(text = f"{rotative01.get()}{rotative02.get()}")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("échelles")
fenetre1.resizable(width = False, height = False)

# sélecteur rotatif donnant le choix d'un nombre
rotative01 = Spinbox(fenetre1, from_ = 1, to = 10, increment = 0.5, command = retourne)
rotative01.pack()

# sélecteur rotatif donne le choix d'une valeur dans un tuple
rotative02 = Spinbox(fenetre1, values = ("bleu", "rouge", "vert", "jaune"), command = retourne)
rotative02.pack()

# étiquette pour afficher les valeurs des sélecteurs
etiquette = Label(fenetre1)
etiquette.pack()

fenetre1.mainloop()
fenetre1.destroy()
