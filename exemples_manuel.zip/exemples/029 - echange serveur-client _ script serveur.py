#!/usr/bin/python3
#-*- coding: utf-8 -*-

### importation du module socketserver ###
import socketserver

### petite phrase pour signaler le début de la session ###
print("Je suis un serveur, j’attends les instructions du client…")

### classe contenant les fonctions du serveur ###
class Appli_Serveur(socketserver.BaseRequestHandler):
    ### la fonction handler gère l’écoute et la réponse ###
    def handle(self): 
        self.data = self.request.recv(1024).strip()            # la variable self.data réceptionne les bytes entrant
        print(f"{self.client_address[0]} a dit : {self.data}") # retourner l’IP du client et son message
        if self.data == (b"salut"):                            # si ce dernier envoi le message ‘salut’ 
            self.request.sendall(b"Bonjour client !")          # le serveur répondra ceci
        else:                                 # dans les autres cas, renvoi juste la phrase du client en majuscule
            self.request.sendall(self.data.upper())

### condition si le script est exécuté depuis un shell $bash ou DOS ###
if __name__ == "__main__":
    HOST, PORT = "localhost", 8008        # en local, sur le port 8008 du pc
    with socketserver.TCPServer((HOST, PORT), Appli_Serveur) as serveur: 
        serveur.serve_forever()           # démarrage du serveur et prise en compte de la classe pour gérer les échanges
