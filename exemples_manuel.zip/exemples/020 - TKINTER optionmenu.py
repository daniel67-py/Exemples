#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# une petite fonction qui va afficher ce que nous avons choisi
def choix(event):
    etiquette.configure(text = f"vous avez choisi : {pointeur.get()}")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("menu d'options")
fenetre1.minsize(width = 300, height = 300)
fenetre1.resizable(width = False, height = False)

# je commence par créer une petite liste 
liste_options = ("pierre", "papier", "ciseaux", "lance-flamme")
# et un pointeur qui indexera cette liste
pointeur = StringVar()
pointeur.set(liste_options[0])

# et je pose mon optionmenu
choix_menu = OptionMenu(fenetre1, pointeur, *liste_options, command = choix)
choix_menu.pack()

# une petite étiquette pour afficher le contenu du pointeur
etiquette = Label(fenetre1, text = "vous avez choisi : ")
etiquette.pack()

fenetre1.mainloop()
fenetre1.destroy()
