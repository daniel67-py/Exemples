#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# une petite fonction pour changer le message de l'étiquette via la méthode .configure du widget Label.
def change_message():
    global stat_etiquette
    if stat_etiquette == 0:
        etiquette1.configure(text = "Salut à tous")
        stat_etiquette = 1
    elif stat_etiquette == 1:
        stat_etiquette = 0
        etiquette1.configure(text = "Hello world")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("Conteneurs")

# une variable qui m'aide à définir quel message afficher
stat_etiquette = 0
# définition de l'étiquette en soit
etiquette1 = Label(fenetre1, text = "Hello world !")
etiquette1.pack()
# et un petit bouton pour appeler la fonction
bouton1 = Button(fenetre1, text = "change", command = change_message)
bouton1.pack()

fenetre1.mainloop()
fenetre1.destroy()
