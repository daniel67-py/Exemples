#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("Conteneurs")

# je défini un cadre 1, qui sera jaune
cadre1 = Frame(fenetre1, background = "yellow", relief = "sunken", borderwidth = 5)
# j'y intègre 2 boutons
bouton1 = Button(cadre1, text = "je suis le bouton 1", command = fenetre1.destroy)
bouton1.grid(row = 1, column = 1, padx = 5, pady = 5)
bouton2 = Button(cadre1, text = "je suis le bouton 2", command = fenetre1.destroy)
bouton2.grid(row = 2, column = 1, padx = 5, pady = 5)
# et je le pose sur la grille de la fenêtre
cadre1.grid(row = 1, column = 1)

# je défini un cadre 2, qui sera bleu
cadre2 = Frame(fenetre1, background = "blue", relief = "sunken", borderwidth = 5)
# j'y intègre aussi 2 boutons
bouton3 = Button(cadre2, text = "je suis le bouton 1", command = fenetre1.destroy)
bouton3.grid(row = 1, column = 1, padx = 5, pady = 5)
bouton4 = Button(cadre2, text = "je suis le bouton 2", command = fenetre1.destroy)
bouton4.grid(row = 2, column = 1, padx = 5, pady = 5)
# et je le pose sur la grille de la fenêtre
cadre2.grid(row = 2, column = 1)

fenetre1.mainloop()
fenetre1.destroy()
