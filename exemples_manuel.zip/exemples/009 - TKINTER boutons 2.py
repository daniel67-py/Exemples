#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

def b1():
    print("je suis bouton 01")
def b2():
    print("je suis bouton 02")
def b3():
    print("je suis bouton 03")
def b4():
    print("je suis bouton 04")

fenetre = Tk()
fenetre.minsize(width = 300, height = 300)
fenetre.resizable(width = False, height = False)
fenetre.title("Bouton")

bouton01 = Button(fenetre, text = "Bouton 1", command = b1)
bouton01.grid(row = 1, column = 1)
bouton02 = Button(fenetre, text = "Bouton 2", command = b2)
bouton02.grid(row = 2, column = 1)
bouton03 = Button(fenetre, text = "Bouton 3", command = b3)
bouton03.grid(row = 1, column = 2)
bouton04 = Button(fenetre, text = "Bouton 4", command = b4)
bouton04.grid(row = 2, column = 2)
bouton05 = Button(fenetre, text = "Quitter", command = fenetre.quit)
bouton05.grid(row = 3, column = 1, columnspan = 2)
    
fenetre.mainloop()
fenetre.destroy()
