#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("menus")
fenetre1.minsize(width = 300, height = 300)
fenetre1.resizable(width = False, height = False)

# pour initialiser une barre de menu et son ou ses sous-menu(s)
barre_de_menu = Menu(fenetre1)
fenetre1['menu'] = barre_de_menu 
sous_menu_01 = Menu(barre_de_menu)
sous_menu_02 = Menu(barre_de_menu)

# et la je peux créer des onglets et les remplir.
# un onglet intitulé ‘premier’ :
barre_de_menu.add_cascade(label = "premier", menu = sous_menu_01)
sous_menu_01.add_command(label = "fonction A", command = fenetre1.quit)
sous_menu_01.add_command(label = "fonction B", command = fenetre1.quit)
sous_menu_01.add_command(label = "fonction C", command = fenetre1.quit)
sous_menu_01.add_separator()
sous_menu_01.add_command(label = "fonction D", command = fenetre1.quit)

# un onglet intitulé ‘second’ :
barre_de_menu.add_cascade(label = "second", menu = sous_menu_02)
sous_menu_02.add_checkbutton(label = "bouton à checker")
sous_menu_02.add_radiobutton(label = "bouton radio")
sous_menu_02.add_separator()
sous_menu_02.add_command(label = "commande standard", command = fenetre1.quit)

# et bien sûr je fini en bouclant ma fenêtre principale
fenetre1.mainloop()
fenetre1.destroy()
