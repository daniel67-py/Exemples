#!/usr/bin/python3
#-*- coding: Utf-8 -*-

class Blocnote():
    # définir les variables propres au programme :
    def __init__(self):
        self.contenu = ""   # le contenu de la note de type str
        self.notes = "blocnote.txt" # le fichier contenant la note

    # affichage d'un petit interface utilisateur en utilisant une fonction
    def principal(self):
        try:    # essai de lecture du fichier si il existe
            with open(self.notes, "r") as fichier:
                self.contenu = fichier.read()
        except: # si il n'existe pas, le créer...
            fichier = open(self.notes, "w")
            fichier.close()

        # affichage du contenu et du choix de l'utilisateur
        print("dernière note : \n".upper(), self.contenu)
        print("Voulez vous : effacer (1), rajouter (2), quitter (3)")
        choix = input("votre choix : ")

        # les conditions et la redirection vers une autre fonction selon le choix
        if choix == "1":
            self.effacer_note()
        elif choix == "2":
            self.rajouter_note()
        elif choix == "3":
            quit()
        else:
            print("ceci n'est pas un choix valable !")
            self.principal()

    # si l'utilisateur souhaite supprimer le contenu
    def effacer_note(self):
        # définition d'un contenu vide
        self.contenu = ""
        # appel du fichier et écriture du nouveau contenu
        with open(self.notes, "w") as fichier:
            fichier.write(self.contenu)
        # et retour à l'interface principale
        self.principal()

    # si l'utilisateur souhaite rajouter du texte à la note existante
    def rajouter_note(self):
        # définition d'un input et petit formatage du message
        note_a_rajouter = input("Rentrez votre message : ")
        note_a_rajouter = note_a_rajouter + "\n"
        # appel du fichier et ajout du message
        with open(self.notes, "a") as fichier:
            fichier.write(note_a_rajouter)
        # et retour à l'interface principale
        self.principal()

# ne reste qu'à définir un nouvel objet Blocnote et appeler la fonction
# principale de ce nouvel objet
essai = Blocnote()
essai.principal()
