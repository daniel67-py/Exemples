#!/usr/bin/python3
#-*- coding: utf-8 -*-
from threading import *

# une classe qui hérite des attributs de l'objet Thread:
class Course_a_pied(Thread):
    # initialisation de la classe
    def __init__(self, nb_pas_min, nb_pas_max, joggeur):
        Thread.__init__(self) # initialisation du thread
        self.nb_pas_min = nb_pas_min
        self.nb_pas_max = nb_pas_max
        self.joggeur = joggeur
    # fonction run, qui va s'activer à l'appel de la méthode .start()
    def run(self):
        with RLock(): # évite un mélange des threads et les synchronisent
            for x in range(self.nb_pas_min, self.nb_pas_max):
                print(f"{self.joggeur} est à : {x}. ")

# une autre classe qui hérite elle aussi des attributs de l'objet Thread:
class Chien_de_course(Thread):
    # initialisation de la classe
    def __init__(self, nb_pas_min, nb_pas_max, chien):
        Thread.__init__(self) # initialisation du thread
        self.nb_pas_min = nb_pas_min
        self.nb_pas_max = nb_pas_max
        self.chien = chien

    # fonction run, qui va s'activer à l'appel de la méthode .start()
    def run(self):
        with RLock(): # évite un mélange des threads et les synchronisent
            for x in range(self.nb_pas_min, self.nb_pas_max):
                print(f"le chien {self.chien} suit à : {x}. ")

# et hop, maintenant que les classes sont prêtes, je passe à la suite… 
# définition d’un athlète et d’un chien
athlete_1 = Course_a_pied(0, 30, "jog_01")
levrier = Chien_de_course(0, 30, "spoutnik")

# les deux commencent la course :
athlete_1.start()
levrier.start()

# le premier arrivé attend l’autre :
athlete_1.join()
levrier.join()

