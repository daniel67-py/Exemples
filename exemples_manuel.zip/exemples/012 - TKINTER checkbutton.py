#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# petite fonction qui change le titre de la fenêtre selon que le check soit valide ou non.
def condition():
    global etat_validation
    if etat_validation == 1:
        etat_validation = 0
        fenetre1.title("le bouton est inactif")
    elif etat_validation == 0:
        etat_validation = 1
        fenetre1.title("le bouton est actif")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.minsize(width = 300, height = 300)
fenetre1.resizable(width = False, height = False)

# variable qui va définir la réaction de la fonction selon l'état du check
etat_validation = 1 
# définition du widget checkbutton
validation = Checkbutton(fenetre1, text = "je suis un checkbutton",
                         command = condition, variable = etat_validation)
validation.pack()

# condition de démarrage
if etat_validation == 1:
    validation.select() # état du widget au démarrage de la fenêtre : actif
elif etat_validation != 1: # il est possible aussi de lui dire d'être .deselect(), soit inactif.
    validation.deselect()
    
fenetre1.mainloop()
fenetre1.destroy()
