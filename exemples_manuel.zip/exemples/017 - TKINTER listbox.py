#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# petite fonction pour retourner la valeur sélectionnée dans la liste
def selection_liste():
    global choix
    try: # pour rester propre, j’essaie de voir si il y a sélection ou non
        # retourne l'index de la ligne sélectionnée
        retourne = liste.curselection()
        # retourne le contenu de la liste à l'index sélectionné
        affiche = liste.get(retourne)
        # affichage du texte dans l'étiquette prévue à cet effet
        etiquette.configure(text = affiche)
    except: # et si il n'y a pas de sélection...
        etiquette.configure(text = "rien !")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("Conteneur étiqueté")

# variable contenant la liste, chaque élément étant simplement espacé d'un espace avec le suivant
choix = StringVar()
choix.set("premier deuxième troisième quatrième")
# définition de la liste
liste = Listbox(fenetre1, listvariable = choix, height = 5)
liste.pack()
# un bouton pour faire l'appel de la fonction
bouton = Button(fenetre1, text = "lequel est sélectionné ?", command = selection_liste)
bouton.pack()
# un label pour retourner le résultat
etiquette = Label(fenetre1, text = "")
etiquette.pack()

fenetre1.mainloop()
fenetre1.destroy()
