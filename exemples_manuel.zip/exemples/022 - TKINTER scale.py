#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# une fonction retournant la valeur des échelles vers une étiquette
def reglage(event):
    etiquette.configure(text = f"{echelle01.get()} par {echelle02.get()}")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("échelles")
fenetre1.resizable(width = False, height = False)

# une première échelle horizontale, allant de 0 à 10 à intervalle de 0.1 et ayant des bornes
# allant de 2 par 2, commandant la fonction reglage
echelle01 = Scale(fenetre1, orient = "horizontal", from_ = 0, to = 10,
                  resolution = 0.1, tickinterval = 2, length = 400, label = "réglage fin",
                  command = reglage)
echelle01.pack()

# une seconde échelle, verticale, allant de 0 à 50 à intervalle de 5 et ayant des bornes allant de
# 10 en 10, commandant la fonction reglage également
echelle02 = Scale(fenetre1, orient = "vertical", from_ = 0, to = 50,
                  resolution = 5, tickinterval = 10, length = 120, label = "réglage gros",
                  command = reglage)
echelle02.pack()

# une étiquette pour afficher les valeurs retournées par les échelles
etiquette = Label(fenetre1, relief = "ridge")
etiquette.pack()

fenetre1.mainloop()
fenetre1.destroy()
