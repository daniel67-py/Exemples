#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# une fonction qui retournera la valeur du bouton sélectionné
def saison():
    retour.configure(text = f"choisissez une valeur : {contrôle.get()}")

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("boutons radio")
fenetre1.resizable(width = False, height = False)

# définition de quelques choix possibles
etiquettes = ["printemps", "été", "automne", "hiver"]
# et un pointeur pour renvoyer la valeur sélectionnée
controle = StringVar()
controle.set(etiquettes[0])
# une petite itération pour générer un groupe de boutons radios
for x in range(4):
    radio = Radiobutton(fenetre1, variable = controle, text = etiquettes[x], value = etiquettes[x], command = saison)
    radio.grid(row = 1, column = x)
# et une étiquette pour afficher la sélection
retour = Label(fenetre1, text = "choisissez une valeur : ")
retour.grid(row = 2, column = 0, columnspan = 4)

fenetre1.mainloop()
fenetre1.destroy()
