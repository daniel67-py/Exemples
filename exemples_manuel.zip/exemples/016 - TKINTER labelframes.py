#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("Conteneur étiqueté")

# définition d'un conteneur étiqueté
conteneur = LabelFrame(fenetre1, text = "Conteneur 1 :")
conteneur.pack()
# deux boutons inclus dans le conteneur pour l'exemple
bouton1 = Button(conteneur, text = "je suis le bouton 1")
bouton1.pack()
bouton2 = Button(conteneur, text = "je suis le bouton 2")
bouton2.pack()

fenetre1.mainloop()
fenetre1.destroy()
