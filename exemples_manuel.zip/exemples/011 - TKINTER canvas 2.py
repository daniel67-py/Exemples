#!/usr/bin/python3
#-*- coding:Utf-8 -*-
from tkinter import *

# programme qui affiche les 5 anneaux olympiques
# quelques variables de positions 
x1, x2, x3, x4 = 20, 50, 35, 65

# définition des fonctions de l'application
def cercles1():  # pour afficher des cercles olympiques bleus
    can1.delete(ALL)        # je nettoie le canvas d'abord pour qu'il soit vierge
    global x1, x2, x3, x4   # appel des variables globales
    for i in range(0, 3):   # deux petits itérateurs pour générer les cercles bleus
            can1.create_oval(x1, 20, x2, 50, outline = "blue", width = 1)
            x1, x2 = x1 + 30, x2 + 30
    for j in range(0, 2):
            can1.create_oval(x3, 35, x4, 65, outline = "blue", width = 1)
            x3, x4 = x3 + 30, x4 + 30
     # et je réinitialise les valeurs d'origines
    x1, x2, x3, x4 = 20, 50, 35, 65

def cercles2(): # pour afficher des cercles olympiques rouges, idem que la fonction du dessus...
    can1.delete(ALL)
    global x1, x2, x3, x4
    for i in range(0, 3):
            can1.create_oval(x1, 20, x2, 50, outline = "red", width = 1)
            x1, x2 = x1 + 30, x2 + 30
    for j in range(0, 2):
            can1.create_oval(x3, 35, x4, 65, outline = "red", width = 1)
            x3, x4 = x3 + 30, x4 + 30

    x1, x2, x3, x4 = 20, 50, 35, 65

# ici je défini la fenêtre principale
fenetre1 = Tk()
fenetre1.title("demonstration canvas")

can1 = Canvas(fenetre1, bg="lightyellow", height=100, width=200)
can1.grid(row = 1, column = 1, rowspan = 2)

bouton1 = Button(fenetre1, text="dessin fonction 1", command=cercles1)
bouton1.grid(row = 1, column = 2)
bouton2 = Button(fenetre1, text="dessin fonction 2", command=cercles2)
bouton2.grid(row = 2, column = 2)
bouton3 = Button(fenetre1, text="Quitter", command=fenetre1.quit)
bouton3.grid(row = 3, column = 1, columnspan = 2)

fenetre1.mainloop()
fenetre1.destroy()

