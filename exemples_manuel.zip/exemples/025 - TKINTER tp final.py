#!/usr/bin/python3
#-*- coding: utf-8 -*-
from tkinter import *
from tkinter.messagebox import *
from tkinter.filedialog import *

# variable contenant le chemin d'accès au fichier en cours.
fichier_source = None

# fonctions de l'application
def nouveau_fichier():
    # ici je pose une question Ok-annuler via un messagebox, si la réponse est oui,
    # efface le texte et demande une autre question Ok-annuler pour nommer le nouveau fichier
    if askokcancel("Nouveau ?", "voulez vous créer un nouveau fichier ?") == True:
        zone_texte.delete("1.0", "end-1c")
        # et si la réponse à la seconde question est oui, redirection vers la fonction
        # enregistre_sous()...
        if askokcancel("nommer ?", "voulez vous déjà donner un nom au nouveau fichier ?") == True:
            enregistre_sous()
    else:
        showerror("action arretée", "action annulée par l'utilisateur")

def effacer():
    # ici je pose une question oui-non via un messagebox, si la réponse est Oui
    # la zone de texte est nettoyée
    if askyesno("effacer le texte", "voulez vous effacer le texte ?") == True:
        zone_texte.delete("1.0", "end-1c")
    else:
        # si la réponse est non, retourne un messagebox pour dire que l'action est annulée
        showerror("action arretée", "action annulée par l'utilisateur")

def enregistre_fichier():
    # ici je pose la question oui-non via un messagebox, si la réponse est Oui
    # et que fichier_source est différent de None...
    if askyesno("enregistrer le fichier", "voulez vous enregistrer ?") == True:
        try:
            contenu_note = zone_texte.get("1.0", "end-1c")
            contenu_note.encode("utf-8")
            with open(fichier_source, "w") as fichier:
                fichier.write(str(contenu_note))
            # prévenir l'utilisateur que le job est fait
            fenetre1.title("Edit - " + fichier_source)
            showinfo("Job fait...", "le fichier a bien été enregistré !")
        except:
            # et si ça ne marche pas, prévenir l'utilisateur de la raison
            showwarning("fichier ?", "aucun fichier cible pour enregistrer !")
    # et si d'emblée je dis non, prévenir que l'action est annulée
    else:
        showerror("action arretée", "action annulée par l'utilisateur")

def ouvrir_fichier():
    # ici je fais appel à la variable fichier_source pour garder le chemin d'accès au fichier
    # que j'ouvre via une boite de dialogue d'ouverture de fichier
    global fichier_source
    fichier_source = askopenfilename(filetypes = [("texte", ".txt")])
    with open(fichier_source, "r") as fichier:
        contenu = fichier.read()
        zone_texte.delete("1.0", "end-1c")
        zone_texte.insert("1.0", contenu)
    fenetre1.title("Edit - " + fichier_source)

def enregistre_sous():
    # ici je fais appel à une boite de dialogue d'enregistrement pour pouvoir enregistrer
    # le contenu de la zone de texte dans un nouveau fichier et garder le chemin d'accès via
    # la variable fichier_source en mémoire en cas de besoin ultérieur.
    fichier_source = asksaveasfilename(filetypes = [("texte", ".txt")])
    contenu_note = zone_texte.get("1.0", "end-1c")
    contenu_note.encode("utf-8")
    with open(fichier_source, "w") as fichier:
        fichier.write(str(contenu_note))
    fenetre1.title("Edit - " + fichier_source)
    showinfo("Job fait...", "le fichier a bien été enregistré !")

def final():
    if askyesnocancel("Fini ?", "voulez vous vraiment quitter ?") == True:
        fenetre1.quit()

def information():
    showinfo("Au sujet de...", "Edit - Programme d'édition de texte basique - Jan.2020 - Meyer Daniel")

### fenêtre de démonstration ###
fenetre1 = Tk()
fenetre1.title("Edit")
fenetre1.resizable(width = False, height = False)
# barre de défilement de haut en bas sur le coté droit de la fenêtre
defilement = Scrollbar(fenetre1)
defilement.pack(side = RIGHT, fill = Y)
# définition d'une zone de texte de 25 ligne de haut et de 80 caractères de large.
zone_texte = Text(fenetre1, height = 25, width = 80, yscrollcommand = defilement.set)
zone_texte.pack(side = LEFT, fill = BOTH)
# et je couple le défilement de la zone de texte de haut en bas avec la zone de texte
defilement.configure(command = zone_texte.yview)
# j'ajoute quelques fonctionnalités via un petit menu
barre_de_menu = Menu(fenetre1)
fenetre1['menu'] = barre_de_menu
sous_menu_01 = Menu(barre_de_menu)
sous_menu_02 = Menu(barre_de_menu)
# et je défini les commandes disponibles pour l'utilisateur
# un menu fichier pour commencer
barre_de_menu.add_cascade(label = "Fichier", menu = sous_menu_01)
sous_menu_01.add_command(label = "Nouveau fichier", command = nouveau_fichier)
sous_menu_01.add_command(label = "Ouvrir un fichier", command = ouvrir_fichier)
sous_menu_01.add_separator()
sous_menu_01.add_command(label = "Enregistrer le fichier", command = enregistre_fichier)
sous_menu_01.add_command(label = "Enregistrer le fichier sous", command = enregistre_sous)                         
sous_menu_01.add_separator()
sous_menu_01.add_command(label = "Effacer la note", command = effacer)
sous_menu_01.add_command(label = "Quitte le bloc-note", command = final)
# un menu infos 
barre_de_menu.add_cascade(label = "Infos", menu = sous_menu_02)
sous_menu_02.add_command(label = "À propos de cette application", command = information)
# et je fini par boucler l'application
fenetre1.mainloop()

# pour arrêter une application tkinter sans déclencher une TclError :
try:
    fenetre1.destroy()
except TclError:
    sys.exit()
