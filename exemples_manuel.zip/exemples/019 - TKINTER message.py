#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from tkinter import *

texte_a_afficher = """
sic transit gloria mundi,
respice post te,
hominem te esse memento,
memento mori
"""

# fenêtre pour la démonstration
fenetre1 = Tk()
fenetre1.title("message")
fenetre1.resizable(width = False, height = False)

# le petit widget message qui va afficher le texte de la variable
texte = Message(fenetre1, text = texte_a_afficher)
texte.pack()
# un petit bouton pour faire jolie
sortie = Button(fenetre1, text = "Ok", command = fenetre1.quit)
sortie.pack()

fenetre1.mainloop()
fenetre1.destroy()
