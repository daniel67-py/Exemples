#!/usr/bin/python3
#-*- coding: Utf-8 -*-
import http.server

PORT = 8008                          # variable comprenant le numéro du port de communication
server_address = ("", PORT)          # variable comprenant l’adresse du serveur, ici il n’y a rien, donc localhost:8008
server = http.server.HTTPServer      # création d’un objet http.server.HTTPServer
handler = http.server.CGIHTTPRequestHandler   # création d’un objet handler CGI pour gérer les réponses du serveur
handler.cgi_directories = [""]                # définition du dossier contenant les scripts CGI spécifiques (si besoin)
print("Serveur actif et à l'écoute sur le port : ", PORT)   # un petit mot pour signaler qu’il fonctionne

directe = server(server_address, handler)        # création d’un objet ‘directe’ utilisant l’objet server.
try:                                             # essai 
    directe.serve_forever()                      # et lancement de la boucle pour le faire tourner non-stop !
except KeyboardInterrupt:                        # exception en cas d’interruption du serveur
    directe.shutdown()                           # arrêt propre du serveur.
