from cx_Freeze import setup, Executable 
import os.path
import sys

# éviter une erreur de type "KeyError: TCL_LIBRARY"
PYTHON_INSTALL_DIR = os.path.dirname(os.path.dirname(os.__file__))
os.environ['TCL_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tcl8.6')
os.environ['TK_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tk8.6')
options = {
    'build_exe': {
        'include_files':[
            os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tk86t.dll'),
            os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tcl86t.dll'),
         ],
    },}

# Si je souhaite compiler pour autre système d'exploitation...
base = None 
if sys.platform == "win32":
    base = "Win32GUI"

# Fichier que je souhaite inclure dans le dossier de l'exécutable
includefiles = ["danielico.ico"]  # le nom de l’icône que je souhaite utiliser pour mon application.

# Paramètres de l'exécutable
target = Executable(
    script = "essai_exe.py",  # le nom du fichier source contenant le programme que je souhaite convertir en .exe
    copyright= "Copyright © 2020 - Meyer Daniel",
    icon = "danielico.ico",  # et le nom de l’icône que je souhaite utiliser
    base = base)

setup( name = "essai_exe", 
    version = "0.1" ,
    description = "" ,
    options = {'build_exe': {'include_files':includefiles}},
    executables = [target])
