#!/usr/bin/python3
#-*- coding: utf-8 -*-
from threading import *

# création d’une classe qui hérite des attributs de l'objet Thread:
class Course_a_pied(Thread):
    # initialisation de la classe
    def __init__(self, nb_pas_min, nb_pas_max, joggeur):
        Thread.__init__(self) # initialisation du thread
        self.nb_pas_min = nb_pas_min
        self.nb_pas_max = nb_pas_max
        self.joggeur = joggeur

    # fonction run, qui va s'activer à l'appel de la méthode .start()
    def run(self):
        with RLock(): # évite un mélange des threads et les synchronisent
            for x in range(self.nb_pas_min, self.nb_pas_max):
                print(f"{self.joggeur} est à : {x}. ")

# définition de 3 threads :
athlete_1 = Course_a_pied(0, 30, "jog_01")
athlete_2 = Course_a_pied(0, 30, "jog_02")
athlete_3 = Course_a_pied(0, 30, "jog_03")

# démarrage des 3 threads en même temps :
athlete_1.start()
athlete_2.start()
athlete_3.start()

# chaque threads attends que les 2 autres soit terminés.
athlete_1.join()
athlete_2.join()
athlete_3.join()
