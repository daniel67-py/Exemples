#!/usr/bin/python3
#-*- coding: utf-8 -*-
from tkinter import *
from tkinter.messagebox import *

# fonctions de l'application
def effacer_note():
    zone_texte.delete("1.0", "end-1c")

def enregistre_note():
    contenu_note = zone_texte.get("1.0", "end-1c")
    contenu_note.encode("utf-8")
    with open("blocnote.txt", "w") as fichier:
        fichier.write(str(contenu_note))
    showinfo("Job fait...", "la note a bien été enregistrée !")

# fenêtre de démonstration
fenetre1 = Tk()
fenetre1.title("Texte")
fenetre1.resizable(width = False, height = False)
# barre de défilement de haut en bas sur le coté droit de la fenêtre
defilement = Scrollbar(fenetre1)
defilement.pack(side = RIGHT, fill = Y)
# définition d'une zone de texte de 25 ligne de haut et de 80 caractères de large
zone_texte = Text(fenetre1, height = 25, width = 80, yscrollcommand = defilement.set)
zone_texte.pack(side = LEFT, fill = BOTH)
# et je couple la barre de défilement de haut en bas avec la zone de texte
defilement.configure(command = zone_texte.yview)
# ouverture d'un fichier qui m'a déjà servi précédemment
with open("blocnote.txt", "r") as fichier:
    contenu = fichier.read()
    contenu.encode("utf-8")
    zone_texte.insert("1.0", contenu)
# j'ajoute quelques fonctionnalités via un petit menu
barre_de_menu = Menu(fenetre1)
fenetre1['menu'] = barre_de_menu
sous_menu_01 = Menu(barre_de_menu)
# et je défini les commandes disponibles pour l'utilisateur
barre_de_menu.add_cascade(label = "note", menu = sous_menu_01)
sous_menu_01.add_command(label = "Effacer la note", command = effacer_note)
sous_menu_01.add_command(label = "Enregistrer la note", command = enregistre_note)
sous_menu_01.add_separator()
sous_menu_01.add_command(label = "Quitte le bloc-note", command = fenetre1.quit)
# et je fini par boucler l'application
fenetre1.mainloop()
fenetre1.destroy()
