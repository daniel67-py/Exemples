#!/usr/bin/python3
#-*- coding: utf-8 -*-

### importation du module socket ###
import socket

### définition d’une petite fonction qui permettra d’envoyer un message sur les sockets du pc ###
def envoyer(instruction):
    HOST, PORT = "localhost", 8008                           # en local, sur le port 8008 du pc
    # ouvre un socket avec un protocole AF_INET (internet standard), et sur un flux standard pour sockets
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock: 
        sock.connect((HOST, PORT))                           # connexion à l’hôte et au port spécifié
        sock.sendall(bytes(instruction + "\n", "utf-8"))     # envoi du message en bytes, encodé en UTF-8
        received = str(sock.recv(8008), "utf-8")             # et réception du message, à décodé en UTF-8
    print(f"instruction envoyée : {instruction}")            # et affichage 
    print(f"instruction reçue : {received}")
