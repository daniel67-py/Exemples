#!/usr/bin/python3
#-*- coding:Utf-8 -*-
import os, sys
from tkinter import *
from math import *

# petite fonction permettant de calculer une opération donnée via le champ Entry
def evaluer(event):
    evaluation = eval(entree.get())
    chaine.configure(text = f"Résultat = {evaluation}")

# petite fenêtre qui contient les widgets
fenetre = Tk()
fenetre.title("Calculatrice")

# définition d’un champ de saisie
entree = Entry(fenetre)
entree.bind("<Return>", evaluer)
entree.pack()

# étiquette permettant d’afficher le résultat
chaine = Label(fenetre)
chaine.pack()

fenetre.mainloop()
