#!/usr/bin/python3
#-*- coding : utf-8 -*-
from tkinter import *

fenetre = Tk()
fenetre.minsize(width = 300, height = 300)
fenetre.resizable(width = False, height = False)
fenetre.title("Canevas")

# je défini la dimension de mon canvas à l’aide de deux variables, w et h
w, h = 290, 290
# je génère l’objet
image = Canvas(fenetre, width = w, height = h)
# la variable ‘affiche’ permet de passer l’image que je souhaite afficher
affiche = PhotoImage(file = "MartinPecheurDessin.gif")
# ne reste qu’à l’intégrer dans le canvas en précisant l’emplacement (w/2 et h/2 me centre l’image)
image.create_image(w / 2, h / 2, image = affiche)
# et j’empaquette le tout
image.pack()

fenetre.mainloop()
fenetre.destroy()
