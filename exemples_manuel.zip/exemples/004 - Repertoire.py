#!/usr/bin/python3
#-*- coding: Utf-8 -*-
from pickle import *

class Repertoire():
    def __init__(self):
        # initialisation des variables de la classe
        self.mon_repertoire = []
        self.fichier_repertoire = "adresses"

    # fonction principale qui fera office de petit interface pour l'utilisateur
    def principal(self):
        # essai d'ouvrir le fichier contenant les données, sinon créé le… 
        try:
            self.mon_repertoire = load(open(self.fichier_repertoire, "rb"))
        except:
            with open(self.fichier_repertoire, "wb") as fichier:
                # retourne cette phrase si un nouveau fichier est créé.
                print("nouveau répertoire initié.")
        # l'affichage de l'interface et du choix de l'utilisateur
        print("\nrépertoire téléphonique".upper())
        print("1. ajouter un contact")
        print("2. supprimer un contact")
        print("3. consulter le répertoire")
        print("4. quitter")
        choix = input("que souhaitez vous faire ? ")
        # fonctions à appeler selon le choix
        if choix == "1":
            self.ajout_contact()
        elif choix == "2":
            self.supprimer_contact()
        elif choix == "3":
            self.consulter_repertoire()
        elif choix == "4":
            quit()
        else:
            print("choix non valable !")
            self.principal()

    # fonction d'ajout d'un contact
    def ajout_contact(self):
        # affichage
        print("\nAjouter un contact :")
        prenom = input("Prénom : ")
        teleph = input("Téléphone : ")
        # traitement des informations données
        contact = {"prenom": prenom, "telephone": teleph}
        self.mon_repertoire.append(contact) # rajout à la liste du dict. contact
        # ne reste qu'à enregistrer le nouveau répertoire en écrasant l'ancien
        dump(self.mon_repertoire, open(self.fichier_repertoire, "wb"))
        print("Contact rajouté !")  # préviens l'utilisateur que le job est ok
        # et reviens à la fonction principale
        self.principal()

    # fonction de suppression d'un contact
    def supprimer_contact(self):
        # affichage
        print("\nQui souhaitez vous supprimer ? ")
        prenom = input("Prénom : ")
        # boucle de recherche du prénom du contact à supprimer
        for x in self.mon_repertoire:
            if x.get("prenom") == prenom:
                self.mon_repertoire.remove(x) # quand tu le trouve, remove...
                print("Contact supprimé !")   # et préviens que c'est fait
        # ne reste qu'à enregistrer le nouveau répertoire en écrasant l'ancien
        dump(self.mon_repertoire, open(self.fichier_repertoire, "wb"))
        # et reviens à la fonction principale
        self.principal()

    def consulter_repertoire(self):
        # affichage du répertoire grâce à une boucle
        print("\nVoilà votre carnet : ")
        for x in self.mon_repertoire:
            print(x.get("prenom"), x.get("telephone"))
        # un input pour ne pas revenir de suite à la fonction principale
        attente = input("appuyez sur entrée pour revenir...")
        # et seulement après validation, retour à la fonction principale
        self.principal()

# appel du notre classe Repertoire en instiguant un nouvel objet
# et en évoquant la fonction principal()
essai = Repertoire()
essai.principal()
